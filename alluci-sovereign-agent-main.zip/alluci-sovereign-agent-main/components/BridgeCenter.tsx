import React, { useState } from 'react';
import { Connection } from '../types';
import { Settings, ChevronDown, ChevronUp } from 'lucide-react';
import ChannelHealthDashboard from '../features/channels/ChannelHealthDashboard';
import ChannelConfigExpansion from '../features/channels/ChannelConfigExpansion';
import ChannelActionResult from '../features/channels/ChannelActionResult';
import IMessagePlatformGuard from '../features/channels/iMessagePlatformGuard';

interface BridgeCenterProps {
    groupedConnections: Record<string, Connection[]>;
    startAuthFlow: (conn: Connection) => void;
    onSocialAction: (id: string, action: string, params: any) => Promise<any> | void;
    onEnterpriseAction: (id: string, action: string, params: any) => Promise<any> | void;
    onPulse: (id: string) => Promise<any> | void;
}

export const BridgeCard: React.FC<{
    conn: Connection;
    startAuthFlow: (conn: Connection) => void;
    onSocialAction: (id: string, action: string, params: any) => Promise<any> | void;
    onEnterpriseAction: (id: string, action: string, params: any) => Promise<any> | void;
    onPulse: (id: string) => Promise<any> | void;
}> = ({ conn, startAuthFlow, onSocialAction, onEnterpriseAction, onPulse }) => {
    const isConnected = conn.status === 'CONNECTED';
    const [configOpen, setConfigOpen] = useState(false);
    const [actionResult, setActionResult] = useState<any>(null);

    const handleActionWrapper = async (actionFn: () => Promise<any> | void) => {
        setActionResult({ status: 'pending', message: 'Executing...' });
        try {
            const res = await actionFn();
            setActionResult(res || { status: 'ok', message: 'Dispatched successfully' });
        } catch (err: any) {
            setActionResult({ status: 'error', message: err.message || 'Action failed' });
        }
    };

    return (
        <div style={{
            background: 'var(--glass-bg)',
            border: `1px solid ${isConnected ? 'rgba(48,209,88,0.20)' : 'var(--separator)'}`,
            borderRadius: 14,
            padding: 16,
            transition: 'all 0.2s ease',
            display: 'flex', flexDirection: 'column', gap: 10,
            backdropFilter: 'blur(16px)',
            position: 'relative',
            overflow: 'hidden',
        }}>
            {/* Subtle top highlight for connected */}
            {isConnected && (
                <div style={{
                    position: 'absolute', top: 0, left: 0, right: 0, height: 2,
                    background: 'linear-gradient(90deg, rgba(48, 209, 88, 0.3), rgba(48, 209, 88, 0.15))', borderRadius: '14px 14px 0 0',
                }} />
            )}

            {conn.id === 'imessage' && <IMessagePlatformGuard />}

            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <div>
                        <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 2 }}>{conn.name}</p>
                        <p style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-tertiary)', textTransform: 'uppercase' }}>{conn.type}</p>
                    </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 3 }}>
                    <span className={`glass-tag ${isConnected ? 'glass-tag--connected' : 'glass-tag--offline'}`} style={{ fontSize: 10 }}>
                        {conn.authType}
                    </span>
                    {conn.isEncrypted && (
                        <span style={{ fontSize: 9, fontWeight: 500, color: 'rgba(48, 209, 88, 0.65)' }}>E2EE</span>
                    )}
                </div>
            </div>

            {/* Connected user info */}
            {isConnected ? (
                <div style={{
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '8px 10px', borderRadius: 10,
                    background: 'var(--fill-quaternary)',
                    border: '1px solid var(--separator)',
                }}>
                    <div style={{ position: 'relative', flexShrink: 0 }}>
                        <img
                            src={conn.profileImg || `https://api.dicebear.com/7.x/identicon/svg?seed=${conn.id}`}
                            style={{ width: 28, height: 28, borderRadius: '50%', border: '1px solid var(--separator)', objectFit: 'cover' }}
                            alt=""
                        />
                        <div style={{
                            position: 'absolute', bottom: -1, right: -1,
                            width: 8, height: 8, borderRadius: '50%',
                            background: 'rgba(48, 209, 88, 0.65)', border: '2px solid var(--bg-elevated)',
                            boxShadow: '0 0 4px rgba(48, 209, 88, 0.2)',
                        }} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontSize: 12, fontWeight: 600, fontFamily: 'var(--font-mono)', color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {conn.accountAlias}
                        </p>
                        <p style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: 'var(--text-quaternary)' }}>
                            ID: {conn.id.substring(0, 8)}
                        </p>
                    </div>

                    {/* Contextual actions — compact */}
                    {conn.id === 'imessage' && (
                        <button onClick={() => handleActionWrapper(() => onPulse(conn.id))} className="glass-btn" style={{ fontSize: 10, padding: '3px 8px', flexShrink: 0 }}>
                            Pulse
                        </button>
                    )}
                    {['tg', 'sg', 'wa', 'dc', 'x', 'fb', 'ig'].includes(conn.id) && (
                        <button onClick={() => handleActionWrapper(() => onSocialAction(conn.id, 'SYNC_FEED', {}))} className="glass-btn" style={{ fontSize: 10, padding: '3px 8px', flexShrink: 0 }}>
                            Sync
                        </button>
                    )}
                    {['sl', 'mt', 'gm', 'gd', 'wechat', 'webchat'].includes(conn.id) && (
                        <button onClick={() => handleActionWrapper(() => onEnterpriseAction(conn.id, 'SEARCH_FILES', {}))} className="glass-btn" style={{ fontSize: 10, padding: '3px 8px', flexShrink: 0 }}>
                            Search
                        </button>
                    )}
                </div>
            ) : (
                <div style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    padding: '8px', borderRadius: 8,
                    border: '1px dashed var(--separator)',
                    background: 'var(--fill-quaternary)',
                }}>
                    <span style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-quaternary)' }}>Offline</span>
                </div>
            )}

            {actionResult && (
                <ChannelActionResult
                    result={actionResult}
                    onDismiss={() => setActionResult(null)}
                />
            )}

            {/* Action button — compact */}
            <div style={{ display: 'flex', gap: 8, width: '100%', marginTop: 'auto' }}>
                <button
                    onClick={() => startAuthFlow(conn)}
                    className={`glass-btn ${isConnected ? 'glass-btn--danger' : 'glass-btn--primary'}`}
                    style={{ flex: 1, padding: '7px', fontSize: 12, fontWeight: 500, textAlign: 'center' }}
                >
                    {isConnected ? 'Disconnect' : 'Connect'}
                </button>
                <button
                    onClick={() => setConfigOpen(!configOpen)}
                    className="glass-btn px-2 text-text-tertiary hover:text-accent flex items-center justify-center transition-colors border border-glass-edge bg-glass-1"
                >
                    <Settings size={14} />
                </button>
            </div>

            <ChannelConfigExpansion
                channelId={conn.id}
                isOpen={configOpen}
                onClose={() => setConfigOpen(false)}
            />
        </div>
    );
};

const BridgeCenter: React.FC<BridgeCenterProps> = ({
    groupedConnections,
    startAuthFlow,
    onSocialAction,
    onEnterpriseAction,
    onPulse
}) => {
    const formatGroupName = (name: string) => name.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());

    const sortConnections = (conns: Connection[]) => {
        return [...conns].sort((a, b) => {
            if (a.status === 'CONNECTED' && b.status !== 'CONNECTED') return -1;
            if (a.status !== 'CONNECTED' && b.status === 'CONNECTED') return 1;
            // Both connected: Could sort by last_message_time if property existed, fall back to alphabetical
            return a.name.localeCompare(b.name);
        });
    };

    return (
        <div style={{ maxWidth: 960, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 32, paddingBottom: 40 }}>

            <ChannelHealthDashboard />

            {(Object.entries(groupedConnections) as [string, Connection[]][]).map(([groupName, groupConns]) => (
                <div key={groupName}>
                    <h3 style={{
                        fontSize: 13, fontWeight: 600, color: 'var(--text-tertiary)',
                        textTransform: 'uppercase', letterSpacing: '0.04em',
                        paddingBottom: 8, marginBottom: 14,
                        borderBottom: '1px solid var(--separator)',
                    }}>
                        {formatGroupName(groupName)}
                    </h3>
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
                        gap: 12,
                    }}>
                        {sortConnections(groupConns).map(conn => (
                            <BridgeCard
                                key={conn.id}
                                conn={conn}
                                startAuthFlow={startAuthFlow}
                                onSocialAction={onSocialAction}
                                onEnterpriseAction={onEnterpriseAction}
                                onPulse={onPulse}
                            />
                        ))}
                    </div>
                </div>
            ))}
        </div>
    );
};

export default BridgeCenter;
